const AppRoute = {
  Game: 'game',
  Results: 'results',
  Rules: 'rules'
};

const TIMEOUT = 900;
const RANDOMIZED = false;
